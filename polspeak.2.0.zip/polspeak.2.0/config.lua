Config = {}
Config.Vehicles = {
  'police',
  'police2',
  'police3',
  'police4',
  'fbi',
  'fbi2',
  'riot2',
  'policet',
  'sheriff',
  'sheriff2',
  'riot',
  'pranger',
  -- Add here your Car's like that
  --'EXAMPLE' <- And Replace EXAMPLE with the SPAWNNAME from your Vehicle --- DONE!
}