fx_version 'adamant'

game 'gta5'

description 'PolSpeak - Police Megaphone by Bronson - RE-Release by Boomatisch | David'

client_script "@NativeUI/NativeUI.lua"
client_scripts {
	'client.lua',
	'config.lua'
}